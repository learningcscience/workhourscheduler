from mainwin import MainWindow
from dbm import DatabaseManager


app = MainWindow()
app.mainloop()



