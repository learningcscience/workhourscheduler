class Scheduler:
    def hours_remaining(self, target, worked):
        pass

    def days_remaining(self):
        pass


    def daily_target(self, hours_remain, days_remain):
        pass