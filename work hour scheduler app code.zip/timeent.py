class TimeEntry:
    def __init__(self, entry_id, date_str, clock_in, clock_out, duration):
        self.id = entry_id
        self.date = date_str
        self.clock_in = clock_in
        self.clock_out = clock_out
        self.duration = duration




        